#include <stdio.h>
#include <string.h>
#include "myscanner.h"

extern int yylex();
extern FILE* yyin;
extern int yylineno;
extern char *yytext;

int assignmentOperator(int inputText)
{
	if (inputText != ASSIGNMENT)
	{
		fprintf(stderr, "Error: Missing assignment operator\n");
		return 1;
	}
}

int checkIdentifier(int inputText)
{
	if (inputText != IDENTIFIER)
	{
		fprintf(stderr, "Error: Missing identifier\n");
		return 1;
	}
}

int checkValue(int inputText)
{
	printf("%d\n", inputText);
	if (inputText != INT_VALUE && inputText != FLOAT_VALUE && inputText != CHAR_VALUE)
	{
		fprintf(stderr, "Error: Missing value constant\n");
		return 1;
	}
}

int checkOperator(int inputText){
	if (inputText != OPERATOR)
	{
		fprintf(stderr, "Error: Missing operator\n");
		return 1;
	}
}


int main(int argc, char* argv[])
{

	// FILE *inputFile = fopen(argv[1], "r");
    // if (!inputFile) {
    //     fprintf(stderr, "Error: Unable to open input file\n");
    //     return 1;
    // }

	// yyin = inputFile;

	int ntoken, vtoken;

	ntoken = yylex();
	while (ntoken){
		switch (ntoken) {
			case KEYWORD:
				ntoken = yylex();
				checkIdentifier(ntoken);
				ntoken = yylex();
				assignmentOperator(ntoken);
				vtoken = yylex();
				checkValue(vtoken);			
				break;

			case IDENTIFIER:
				ntoken = yylex();
				assignmentOperator(ntoken);
				vtoken = yylex();
				checkIdentifier(vtoken);
				ntoken = yylex();
				checkOperator(ntoken);
				vtoken = yylex();
				checkIdentifier(vtoken);
				break;

			default:
				// ignore other tokens
				break;
		}
		printf("%d\n", ntoken);
		ntoken = yylex();
	}

	return 0;
}