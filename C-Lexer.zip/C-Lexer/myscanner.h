#define KEYWORD 1
#define ASSIGNMENT 2
#define IDENTIFIER 3
#define INT_VALUE 4
#define FLOAT_VALUE 5
#define CHAR_VALUE 6
#define OPERATOR 7