int a_1 = 6;
float f_2 = 6;
char c_3 = 'a';

a_1 = a_1 + f_2;
a_1 = a_1 - f_2;
a_1 = a_1 * f_2;
// a_1 -= c